// Replace with your actual API key
export const GEMINI_API_KEY = 'AIzaSyAEgJlLhoYVUWMB5iSPXKi6BNOZ3EQyZVE';

export const DEFAULT_GREETING = "Hello! I'm an AI assistant powered by Gemini. How can I help you today?";

// API Configuration
export const API_TIMEOUT = 30000; // 30 seconds
export const MAX_RETRIES = 3;